# IronSignal — Prog Metal VST3 Amp Simulator

Elektro gitar için high-gain amp simulator. Djent, death metal, prog metal.

## Kurulum (Windows)

1. Sağ üstten **Actions** sekmesine gir
2. **Build IronSignal VST3 (Windows)** workflow'u seç
3. **Run workflow** butonuna bas
4. 3-5 dakika bekle
5. İş bitince **Artifacts** bölümünden `IronSignal-VST3-Windows.zip` indir
6. Zip'i aç → `IronSignal.vst3` klasörünü kopyala:
   ```
   C:\Program Files\Common Files\VST3\IronSignal.vst3
   ```
7. DAW'ı aç, plugin taraması yap — IronSignal görünecek

## Kontroller

| Parametre | Açıklama |
|---|---|
| GAIN | Distortion miktarı |
| KEMİK (Tightness) | Alt frekans sıkılığı — palm mute kemikleşir |
| SERTLİK (Presence) | Pick attack keskinliği, 4.5kHz |
| BASS / MID / TREBLE | 3-band EQ |
| MASTER | Çıkış seviyesi |
| BOOST | Gain'i 2x artırır |
| GATE | Noise gate — sessizlik anlarında gürültüyü keser |
| CAB SIM | Kabin simulasyonu — açık: mikrofona alınmış ses |
| DELAY | Yankı efekti |

## Presetler

- **DJENT** — Periphery / Tesseract tarzı sıkı, modern
- **DEATH METAL** — Ezici, kalın, agresif  
- **PROG** — Açık, dinamik, delay'li
- **CLEAN** — Distorsiyonsuz, temiz

## Teknik

- Format: VST3 (64-bit Windows)
- Oversampling: 4x (aliasing önleme)
- Asymmetric waveshaping (tüp benzeri harmonikler)
- Noise gate: envelope follower tabanlı
- Cab sim: lowpass + highpass zinciri
- Preset memory: DAW projesiyle kaydedilir
